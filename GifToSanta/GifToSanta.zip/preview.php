<!DOCTYPE>
<html>
<head>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script>
		jQuery( document ).ready( function() {

			$('#button').click(function(){				  
				
				var action = 'send_to_santa.php';
				var filename = '<?php echo $_GET['gifname']; ?>';
				$.post(action, { 
					file: filename,
					email: $('#mailSanta').val(),
					subject: $('#subjectSanta').val(),
					message: $('#messageSanta').val()
					},
					function(data){
						$('#santaForm ').attr('disabled','');
						$('.response').remove();
						$('#santaForm').before('<p class="response">'+data+'</p>');
						$('.response').slideDown();
					});
				});
			});

	</script>
	<link type ="text/css" rel="stylesheet" href="stylesheet.css"/>
		
	<title>Gif to Santa </title>
</head>
<body>
	<div id = "header">
		<div id = "logo"><img src = "title.png" align = "left" width = "400px" height = "200px" /></div>
	</div>
	<div id = "main_content">
		<div id = "showGif">
			 <img src = "images/savings/<?php echo $_GET['gifname']; ?>" height="300px" width="460px" style="margin:25px auto;" >
			 <br><br>

			 <div id = "santaForm">
			 
			  &nbsp;&nbsp;Email: &nbsp;&nbsp;<input type = "text" id = "mailSanta"><br><br>
			  &nbsp;&nbsp;Subject: <input type = "text" id = "subjectSanta"><br><br>
			  &nbsp;&nbsp;Message:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			   <textarea rows = "10" cols = "60" id = "messageSanta"></textarea><br><br>
			  
			  &nbsp;&nbsp;<button type="button" id="button">Send it to Santa</button>
			  <br><br>

			  &nbsp;&nbsp;Get your Gif!
			  &nbsp;&nbsp;<a href='get_your_gif.php?file=<?php echo $_GET['gifname']; ?>'>Download</a>
			  <br /><br />

			</div>
			 
			 
		</div>

	</div>
</body>
</html>