<?php

if ( isset($_POST) )
{
	$file = $_POST['file'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];

	$to = $email;
	$subject = $subject;
	
	$from = "annost27@yahoo.com";
	$headers = "From:" . $from;

	// mail($to,$subject,$message,$headers);

	echo "TO: $to, SUBJECT: $subject, MESSAGE: $message, HEADER: $headers, FILE: $file";
}
else echo "Something goes WRONG !";

?>