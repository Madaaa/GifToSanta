<!DOCTYPE>
<html> 
<head>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script>

		$( document ).ready(function() {
			
			$('#button').click(function(){

				nume = $('#name').val();
				lastChar = nume.substr(nume.length - 1);

				var array = new Array();
				
				if(lastChar === 'a') 
					ImgName = 'f';
				else
					ImgName = 'b';

				ImgName += '2';
				val = $('input:radio[name=2]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';

				//alert(ImgName);

				array[0] = ImgName;
				ImgName = ImgName[0];
				//alert(ImgName);

				ImgName += '3';
				val = $('input:radio[name=3]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';
				array[1] = ImgName;
				ImgName = ImgName[0];

				ImgName += '4';
				val = $('input:radio[name=4]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';
				array[2] = ImgName;
				ImgName = ImgName[0];

				ImgName += '5';
				val = $('input:radio[name=5]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg ';
				array[3] = ImgName;
				ImgName = ImgName[0];

				ImgName += '6';
				val = $('input:radio[name=6]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';
				array[4] = ImgName;
				ImgName = ImgName[0];

				ImgName += '7';
				val = $('input:radio[name=7]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';
				array[5] = ImgName;
				ImgName = ImgName[0];

				ImgName += '8';
				val = $('input:radio[name=8]:checked').val();
				ImgName = ImgName + val;
				ImgName = ImgName + '.jpg';
				array[6] = ImgName;
	           
				var action = 'images/prepare.php';
				$.post(action, { 
					frames: array,
					name: nume
					},
					function(data){
						$('#formular #submit').attr('disabled','');
						$('.response').remove();
						$('#formular').before('<p class="response">'+data+'</p>');
						$('.response').slideDown();
					}
				);
				
				$('html, body').animate({ scrollTop: 0 }, 0); 
			});

		});

	</script>
	<link type ="text/css" rel="stylesheet" href="stylesheet1.css"/>
	<title>GIF to Santa </title>

</head>
<body>
	<div id = "header">
		<div id = "logo"><img src = "title.png" align = "left" width = "400px" height = "200px" /></div>
	</div>

	<div id = "formular">
		<p>&nbsp;&nbsp;<i>1. Type your name:</i></p>
		&nbsp;&nbsp;
		<input type = "text" name = "name" id="name"><br><br>

		<p>&nbsp;&nbsp;<i>2. How do you spent your freetime?<i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "2" value = "1"> Dancing in the  club<br>
		&nbsp;&nbsp;
		<input type = "radio" name = "2" value = "2"> Learning<br>
		&nbsp;&nbsp;
		<input type = "radio" name = "2" value = "3"> Gaming<br><br>

		<p>&nbsp;&nbsp;<i>3. Hobbys: </i> </p>
		&nbsp;&nbsp;
		<input type = "radio" name = "3" value = "1"> Shopping <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "3" value = "2"> Sports <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "3" value = "3"> Programming <br><br>

		<p>&nbsp;&nbsp;<i>4. Describe you in one word:</i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "4" value = "1"> Calm <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "4" value = "2"> Organized <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "4" value = "3"> Dizzy <br><br>

		<p>&nbsp;&nbsp;<i>5. Favourite music:</i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "5" value = "1"> Rock <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "5" value = "2"> Classical Music <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "5" value = "3"> Reggae <br><br>

		<p>&nbsp; &nbsp; <i> 6. Perfect vacation involves:</i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "6" value = "1"> Seaside <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "6" value = "2"> Mountain <br><br>

		<p>&nbsp;&nbsp; <i> 7. This year you have been a good person: </i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "7" value = "1"> > 50% <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "7" value = "2"> < 50% <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "7" value = "3"> = 50% <br><br>

		<p>&nbsp;&nbsp; <i> 8. What do you want for Christams? </i></p>
		&nbsp;&nbsp;
		<input type = "radio" name = "8" value = "1"> To snow <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "8" value = "2"> To have all my friends around me <br>
		&nbsp;&nbsp;
		<input type = "radio" name = "8" value = "3"> Santa to come with good grades on the finals <br><br>
       
        <div id = "btn">
			<button type = "button"  id = "button" name = "showGif"> Create Gif </button> <br><br><br>
		</div>

	</div>		

</body>


</html>